package com.example.cineplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.example.cineplus.repositorio.UserRepository
import com.example.cineplus.viewmodel.ProfileViewModel
import com.example.cineplus.ui.navigation.NavGraph
import com.example.cineplus.ui.theme.CinePlusTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val repositorioUsuario = UserRepository(this)
        val modeloVista = ProfileViewModel(repositorioUsuario)

        setContent {
            CinePlusTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    NavGraph(modeloVista = modeloVista)
                }
            }
        }
    }
}
