package com.example.cineplus.repositorio

class AuthRepository {
}