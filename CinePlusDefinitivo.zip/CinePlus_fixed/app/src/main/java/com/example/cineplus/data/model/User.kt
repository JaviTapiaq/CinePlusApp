package com.example.cineplus.data.model

data class User(
    val id: String,
    val correo: String,
    val name: String
)