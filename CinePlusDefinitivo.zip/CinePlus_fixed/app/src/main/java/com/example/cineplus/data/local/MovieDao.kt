package com.example.cineplus.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.cineplus.data.model.Movie

@Dao
interface MovieDao {

    @Insert
    suspend fun insertMovie(pelicula: Movie)

    @Query("SELECT * FROM peliculas")
    suspend fun getAllMovies(): List<Movie>

    @Query("DELETE FROM peliculas")
    suspend fun deleteAllMovies()
}
