package com.example.cineplus.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "entradas")
data class Ticket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val movieId: Int,
    val seatNumber: String,
    val date: String
)

