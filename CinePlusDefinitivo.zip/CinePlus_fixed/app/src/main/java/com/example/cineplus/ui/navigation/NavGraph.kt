package com.example.cineplus.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.cineplus.ui.screens.LoginScreen
import com.example.cineplus.ui.screens.ProfileScreen
import com.example.cineplus.viewmodel.ProfileViewModel

@Composable
fun NavGraph(modeloVista: ProfileViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "iniciarSesion") {

        // Pantalla de inicio de sesión
        composable("iniciarSesion") {
            LoginScreen(
                navController = navController,
                alIniciarSesion = {
                    // Cuando se inicia sesión correctamente
                    navController.navigate("perfil")
                }
            )
        }

        // Pantalla de perfil
        composable("perfil") {
            ProfileScreen(
                navController = navController,
                modeloVista = modeloVista
            )
        }
    }
}


