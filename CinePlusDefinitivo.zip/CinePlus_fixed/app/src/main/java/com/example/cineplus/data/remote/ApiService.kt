package com.example.cineplus.data.remote

import com.example.cineplus.data.remote.dto.LoginRequest
import com.example.cineplus.data.remote.dto.LoginResponse
import com.example.cineplus.data.remote.dto.UserDto
import com.example.cineplus.data.remote.dto.UsersResponse
import retrofit2.http.*

interface ApiService {

    @POST("user/iniciarSesion")
    suspend fun iniciarSesion(@Body request: LoginRequest): LoginResponse

    @GET("users/search")
    suspend fun searchUsers(@Query("q") query: String): UsersResponse

    @GET("users/{id}")
    suspend fun getUser(@Path("id") id: Int): UserDto

    @GET("users/{id}")
    suspend fun getUserById(@Path("id") id: Int): UserDto
}
