package com.example.cineplus.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.cineplus.data.model.Movie
import com.example.cineplus.data.model.Ticket

@Database(entities = [Movie::class, Ticket::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun movieDao(): MovieDao
    abstract fun ticketDao(): TicketDao
}
