package com.example.cineplus.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cineplus.data.local.AppDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.cineplus.data.model.Movie

class MovieListViewModel(private val db: AppDatabase) : ViewModel() {

    private val _movies = MutableStateFlow<List<Movie>>(emptyList())
    val peliculas: StateFlow<List<Movie>> = _movies

    init {
        loadMovies()
    }

    private fun loadMovies() {
        viewModelScope.launch {
            _movies.value = db.movieDao().getAllMovies()
        }
    }
}
