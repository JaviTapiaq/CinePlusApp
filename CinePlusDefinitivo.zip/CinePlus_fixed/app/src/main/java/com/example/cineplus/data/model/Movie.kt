package com.example.cineplus.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "peliculas")
data class Movie(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val year: Int = 0,
    val genre: String = "",
    val description: String = "",
    val image: String = ""
)
