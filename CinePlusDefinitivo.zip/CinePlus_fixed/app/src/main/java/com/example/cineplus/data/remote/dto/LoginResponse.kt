package com.example.cineplus.data.remote.dto

import com.google.gson.annotations.SerializedName

/**
 * DTO para la respuesta de iniciarSesion
 * Datos que RECIBIMOS del servidor tras iniciarSesion exitoso
 */
data class LoginResponse(
    @SerializedName("id")
    val id: Int,

    @SerializedName("nombreUsuario")
    val nombreUsuario: String,

    @SerializedName("correo")
    val correo: String,

    @SerializedName("firstName")
    val firstName: String,

    @SerializedName("lastName")
    val lastName: String,

    @SerializedName("accessToken")
    val accessToken: String,  // TOKEN JWT - Lo guardamos en SessionManager

    @SerializedName("refreshToken")
    val refreshToken: String?  // Opcional - Para renovar el token
)