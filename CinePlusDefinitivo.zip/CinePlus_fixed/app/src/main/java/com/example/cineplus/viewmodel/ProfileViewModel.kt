package com.example.cineplus.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cineplus.repositorio.UserRepository
import com.example.cineplus.data.remote.dto.UserDto
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableStateOf

class ProfileViewModel(private val repositorioUsuario: UserRepository) : ViewModel() {

    var nombreUsuario = mutableStateOf("")
    var correoUsuario = mutableStateOf("")
    var cargando = mutableStateOf(false)
    var errorMensaje = mutableStateOf<String?>(null)

    fun cargarUsuario(id: Int = 1) {
        viewModelScope.launch {
            cargando.value = true
            val resultado = repositorioUsuario.obtenerUsuario(id)

            resultado.onSuccess { usuario ->
                nombreUsuario.value = usuario.nombre
                correoUsuario.value = usuario.correo
                errorMensaje.value = null
            }.onFailure { e ->
                errorMensaje.value = e.message
            }
            cargando.value = false
        }
    }
}
