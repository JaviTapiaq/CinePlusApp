package com.example.cineplus.data.remote.dto

import com.google.gson.annotations.SerializedName

/**
 * DTO para la petición de iniciarSesion
 * Datos que ENVIAMOS al servidor
 */
data class LoginRequest(
    @SerializedName("nombreUsuario")
    val nombreUsuario: String,

    @SerializedName("contraseña")
    val contraseña: String,

    @SerializedName("expiresInMins")
    val expiresInMins: Int = 30
)