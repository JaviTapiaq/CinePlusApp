package com.example.cineplus.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.cineplus.data.model.Ticket

@Dao
interface TicketDao {

    @Insert
    suspend fun insertTicket(entrada: Ticket)

    @Query("SELECT * FROM entradas")
    suspend fun getAllTickets(): List<Ticket>

    @Query("DELETE FROM entradas")
    suspend fun deleteAllTickets()
}
