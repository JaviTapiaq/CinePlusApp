package com.example.cineplus.repositorio

import android.content.Context
import com.example.cineplus.data.remote.ApiService
import com.example.cineplus.data.remote.RetrofitClient
import com.example.cineplus.data.remote.dto.UserDto

class UserRepository(context: Context) {

    private val apiService: ApiService = RetrofitClient
        .getClient(context)
        .create(ApiService::class.java)

    suspend fun obtenerUsuario(id: Int = 1): Result<UserDto> {
        return try {
            val usuario = apiService.getUser(id)
            Result.success(usuario)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

